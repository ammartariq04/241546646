package com.example.createzero.viewmodel

import com.example.bodyanalysistool.data.ImageDownloadedResponse


data class ImageDownloadedState(
    val imageDownloadedResponse: ImageDownloadedResponse? = null
)
