package com.example.bodyanalysistool.data

data class AuthResult(
    val user: User? = null,
    val errorMessage: String? = "null"
)
