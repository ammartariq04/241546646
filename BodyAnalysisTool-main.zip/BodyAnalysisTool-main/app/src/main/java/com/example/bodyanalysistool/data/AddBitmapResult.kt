package com.example.bodyanalysistool.data

data class AddBitmapResult(
    val isSuccessful: Boolean = false,
    val errorMessage: String? = null
)
