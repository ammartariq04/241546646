package com.example.bodyanalysistool.viewmodel

data class Session(
    val bitmapState: BitmapState,
    val geminiAIUiState: GeminiAIUiState
)