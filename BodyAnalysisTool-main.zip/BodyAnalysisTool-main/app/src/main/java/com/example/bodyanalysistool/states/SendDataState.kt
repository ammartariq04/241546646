package com.example.bodyanalysistool.states

import com.example.bodyanalysistool.data.SendDataResponse

data class SendDataState(
    val sendDataResponse: SendDataResponse? = null
)
