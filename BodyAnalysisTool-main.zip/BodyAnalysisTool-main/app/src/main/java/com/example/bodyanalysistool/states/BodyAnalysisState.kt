package com.example.createzero.viewmodel

import com.example.bodyanalysistool.data.BodyAnalysisResponse


data class BodyAnalysisState(
    val bodyAnalysisResponse: BodyAnalysisResponse? = null
)
