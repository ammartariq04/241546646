package com.example.bodyanalysistool.data

data class BitmapUri(
    val uriID: String? = null,
    val uri: String? = null
)
