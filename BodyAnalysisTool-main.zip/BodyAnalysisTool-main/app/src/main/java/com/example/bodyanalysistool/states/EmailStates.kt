package com.example.bodyanalysistool.states

data class EmailStates(
    val email: String? = ""
)
