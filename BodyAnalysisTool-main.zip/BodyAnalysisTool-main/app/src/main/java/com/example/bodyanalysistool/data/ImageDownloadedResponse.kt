package com.example.bodyanalysistool.data

data class ImageDownloadedResponse(
    val imageDownloaded: String
)
