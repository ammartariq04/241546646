package com.example.bodyanalysistool.states

data class PasswordStates(
    val password: String? = ""
)
