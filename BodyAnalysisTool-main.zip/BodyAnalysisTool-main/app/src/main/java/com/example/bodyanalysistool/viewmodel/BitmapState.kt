package com.example.bodyanalysistool.viewmodel

data class BitmapState(
    val bitmapUri: String? = null
)
