package com.example.bodyanalysistool.utils

object Constraints {
    const val USERS = "users"
}