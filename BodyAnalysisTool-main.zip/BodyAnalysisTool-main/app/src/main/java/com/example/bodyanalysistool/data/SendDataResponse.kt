package com.example.bodyanalysistool.data

data class SendDataResponse(
    val isSuccessful: Boolean = false,
    val errorMessage: String? = null
)
