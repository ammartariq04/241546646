package com.example.bodyanalysistool.data

data class StorageRef(
    val referencePath: String
)
