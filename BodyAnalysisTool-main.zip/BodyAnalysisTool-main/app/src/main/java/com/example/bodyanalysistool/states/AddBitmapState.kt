package com.example.bodyanalysistool.states

import com.example.bodyanalysistool.data.AddBitmapResult

data class AddBitmapState(
    val addBitmapResult: AddBitmapResult? = null
)
