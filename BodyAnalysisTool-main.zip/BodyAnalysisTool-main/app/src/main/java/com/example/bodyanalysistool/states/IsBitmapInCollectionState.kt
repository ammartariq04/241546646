package com.example.bodyanalysistool.states

import com.example.bodyanalysistool.data.IsBitmapInCollectionResult

data class IsBitmapInCollectionState(
    val isBitmapInCollectionResult: IsBitmapInCollectionResult? = null
)
