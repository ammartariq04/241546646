package com.example.bodyanalysistool.utils

object Util {
    private const val ipv4Address = "192.168.206.31"
    const val baseUrl = "http://$ipv4Address:8080"
}