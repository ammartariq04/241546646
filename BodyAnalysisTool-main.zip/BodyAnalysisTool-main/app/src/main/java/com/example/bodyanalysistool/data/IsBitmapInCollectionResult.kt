package com.example.bodyanalysistool.data

data class IsBitmapInCollectionResult(
    val found: Boolean = false,
    val errorMessage: String? = null
)
