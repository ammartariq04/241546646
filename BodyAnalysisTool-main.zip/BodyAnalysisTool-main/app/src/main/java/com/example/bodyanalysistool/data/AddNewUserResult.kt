package com.example.bodyanalysistool.data

data class AddNewUserResult(
    val isSuccessful: Boolean = false,
    val errorMessage: String? = null
)