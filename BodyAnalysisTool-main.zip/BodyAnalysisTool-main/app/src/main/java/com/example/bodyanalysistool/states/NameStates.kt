package com.example.bodyanalysistool.states

data class NameStates(
    val name: String? = ""
)
