package com.example.bodyanalysistool

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BodyAnalysisToolApplication : Application()