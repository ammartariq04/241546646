package com.example.bodyanalysistool.viewmodel

data class GeminiAIUiState (
    val isLoading: Boolean? = null,
    val response: String? = null,
    val isSuccessful: Boolean = false
)